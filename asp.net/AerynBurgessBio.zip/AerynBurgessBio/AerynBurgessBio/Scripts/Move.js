﻿$(document).ready(function () {
    $(".jumbotron").fadeIn(5000);
    $(".col-md-4").slideUp(30000);
});

