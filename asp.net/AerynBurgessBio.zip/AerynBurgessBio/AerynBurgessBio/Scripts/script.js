$(document).ready(function() {
$("#link").fadeIn(9000);
});
