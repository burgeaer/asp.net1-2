﻿(function () {
    var app = angular.module("atTheMovies", ["ngRoute"]);
    var config = function ($routeProvider) {
        $routeProvider
            .when("/List",
                { templateUrl: "/client/views/list.html" })
            .when("/details/:id",
                { templateUrl: "/client/views/details.html" })
            .otherwise(
            { redirectTo: "/List" });
    };
    app.config(config);
}());